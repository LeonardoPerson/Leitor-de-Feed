O leitor de Feed é uma ferramenta que permite a pré-leitura do conteúdo de um site sem precisar acessá-lo.
O atual leitor possui um menu de acesso às opções disponíveis pelo canto superior esquerdo da tela.
As opções disponíveis são: Udacity Blog, CSS Tricks, HTML5 Rocks, Linear Digressions.
Cada opção reúne um grupo de links contendo informações em comum.
Ao clicar no link, o leitor é direcionado ao site que contém a informação.