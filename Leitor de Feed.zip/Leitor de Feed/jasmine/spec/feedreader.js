/* feedreader.js
 *
 * This is the spec file that Jasmine will read and contains
 * all of the tests that will be run against your application.
 */

/* We're placing all of our tests within the $() function,
 * since some of these tests may require DOM elements. We want
 * to ensure they don't run until the DOM is ready.
 */
$(function() {
    /* This is our first test suite - a test suite just contains
    * a related set of tests. This suite is all about the RSS
    * feeds definitions, the allFeeds variable in our application.
    */
    describe('RSS Feeds', function() {
        //Esse teste garante que a variável allFeeds está definida e não está vazia
        it('are defined', function() {
            expect(allFeeds).toBeDefined();
            expect(allFeeds.length).not.toBe(0);
        });
        //Esse teste verifica se existe URL válida pelas propriedades da variável allFeeds
        it('URL defined', function(){
            let x;
            for(x = 0; x < allFeeds.length; x++){
                expect(allFeeds[x].url.trim()).not.toBe('');
            }
        });
        //Esse teste verifica se existe nome válido pelas propriedades da variável allFeeds
        it('name defined', function(){
            let y;
            for(y = 0; y < allFeeds.length; y++){
                expect(allFeeds[y].name.trim()).not.toBe('');
            }
         });
    });


    describe('The menu', function(){
        //Esse teste garante que o menu esteja oculto por padrão
        it('Menu oculto', function(){
            let menuOculto = document.body;
            expect(menuOculto).toBeDefined();
            expect(menuOculto).toHaveClass('menu-hidden');
        });
        //Esse teste garante que o menu torne-se visível quando é acionado
        it('Exibe menu', function(){
            let exibeMenu = document.querySelector('a');
            expect(exibeMenu).toBeDefined();
            expect(exibeMenu).toHaveClass('menu-icon-link');
        });
        //Esse teste garante que o menu torne-se oculto quando é acionado
        it('Oculta menu', function(){
            let ocultaMenu = document.querySelector('a');
            expect(ocultaMenu).toBeDefined();
            expect(ocultaMenu).toHaveClass('menu-icon-link');
        });
    });

    describe('Initial Entries', function(){
        //Teste para garantir que exista ao menos um link definido após a função loadFeed() executar seu trabalho
        beforeEach(function(done){
            loadFeed(0, function(){
                done();
            });
        });

        it('link existente', (function(){
            let feed = document.getElementsByClassName('entry');
            expect(feed).toBeDefined();
            expect(feed.length).toBeGreaterThan(0);
        }));
    });


    describe('Nova seleção de feed', function(){
        //Teste para garantir que quando um novo feed é carregado, o conteúdo realmente mudará
        let id = 0;
        beforeEach(function(done){
            loadFeed(id, function(){
                done();
            });
        });

        it('Carregamento de novo feed', function(){
            expect(id).toBeDefined();
        });
    });


}());
